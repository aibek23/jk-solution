const Footer = () => {
  return <footer className='container'>
        Created &copy; BIS
  </footer>;
};

export default Footer;
