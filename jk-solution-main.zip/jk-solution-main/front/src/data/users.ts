export const users = [
  {
    id: '1',
    email: 'baktybeks@mail.ru',
    name: 'baktybeks',
    password: 'baktybeks',
    role: 'admin',
  }, {
    id: '2',
    email: 'admin@mail.ru',
    name: 'admin',
    password: 'admin',
    role: 'admin',
  },
];
