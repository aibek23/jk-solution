export default function Team() {
  return <h1>Team</h1>;
}
